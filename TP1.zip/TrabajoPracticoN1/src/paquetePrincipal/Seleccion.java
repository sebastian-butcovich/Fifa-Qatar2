package paquetePrincipal;
/**
 * Define las caracteriticas y comportamientos que tiene un jugador en nuestro modelo de la FIFA
 * @author Lucas, Martin, Sebastian
 * @version 1.0*/
public class Seleccion {
	private Jugador[] seleccion;
	//private Estadisticas-Seleccion estadistica;
	private String confederacion;
	private int finales;
	/**
	 * construnctor de la clase seleccion, no recibe parametro*/
	public Seleccion()
	{
		
	}
	/**
	 * Devuelve un arreglo de jugadores con todos los jugadores de una seleccion particular
	 * @return devuelve un arreglo de jugadores, con todos los jugadores de una seleccion
	 * @see Jugador*/
	public Jugador[] getSeleccion() {
		return seleccion;
	}
	/**
	 * Define los jugadores de una seleccion
	 * @param seleccion es un arreglo que contiene jugadores de una seleccion
	 * @see Jugador*/
	public void setSeleccion(Jugador[] seleccion) {
		this.seleccion = seleccion;
	}
	/**
	 * Devuelve la confederacion de una seleccion*/
	public String getConfederacion() {
		return confederacion;
	}
	/**
	 * Define la confederacion de una seleccion*/
	public void setConfederacion(String confederacion) {
		this.confederacion = confederacion;
	}
	/** Devuelve el numero de finales de una seleccion*/
	public int getFinales() {
		return finales;
	}
	/** Define el numero de finales de una seleccion*/
	public void setFinales(int finales) {
		this.finales = finales;
	}
	
}
