package paquetePrincipal;
/**
 * Clase jugador reperesenta las caracteristicas y funcciones que representan a un jugador en u nuestro modelo de la FIFA
 * @author Lucas Martin Sebastian
 * @version 1.0
 * */
public class Jugador extends Persona {
	private int goles;
	private int asistencias;
	private int minutosJugados;
	private double efectividad;
	private int premiosGanados;
	/**
	 * Constructor vacio de la clase jugador , crea un objeto Jugador*/
	public Jugador()
	{
		
	}
	/**
	 * getGoles te permite recuperar el valor de la variable de instancia goles de la instancia de la clase Jugador
	 * @return devuelve la cantidad de goles que hizo el jugador*/
	public int getGoles() {
		return goles;
	}
	/**
	 * setGoles te permite asignarle un valor a la variable goles
	 * @param goles define el numero de goles del jugador*/
	public void setGoles(int goles) {
		this.goles = goles;
	}
	/**
	 * getAsistencias devuelve el valor de la variable de instancia asistencia
	 * @return asistencia contiene un valor numerico*/
	public int getAsistencias() {
		return asistencias;
	}
	/**
	 * setAsistencias le asigna un valor pasado por parametro a la variable de instancai asistencias
	 * @param asistencias tiene un valor numerico*/
	public void setAsistencias(int asistencias) {
		this.asistencias = asistencias;
	}
	/**
	 * getMinutosJugados devuelve el valor de la variable minutosJugados
	 * @return minutosJugados devuelve un valor numerico */
	public int getMinutosJugados() {
		return minutosJugados;
	}
	/**
	 * setMinutosJugados le asigna un valor pasado por parametro a la variable de instancia minutosJugados
	 * @param minutosJugados tiene un valor numerico*/
	public void setMinutosJugados(int minutosJugados) {
		this.minutosJugados = minutosJugados;
	}
	/**
	 * getEfectividad devuelve el valor de la variable de instancia efectividad
	 * @return devuelve un valor numerico */
	public double getEfectividad() {
		return efectividad;
	}
	/**
	 * setEfectividad le asigna un valor pasado por parametro a la variable de instancia efectividad
	 * @param efectividad contiene un valor numerico*/
	public void setEfectividad(double efectividad) {
		this.efectividad = efectividad;
	}
	/**
	 * getPremiosGanados devuelve el valor de la variable de instancia premiosGanados
	 * @return devuelve un valor numerico*/
	public int getPremiosGanados() {
		return premiosGanados;
	}
	/**
	 * setPremiosGanados le asigna un valor a la variable de instancia premiosGanadso
	 * @param premiosGanados tiene un valor numerico*/
	public void setPremiosGanados(int premiosGanados) {
		this.premiosGanados = premiosGanados;
	}
}
