package paquetePrincipal;
/**
 * Clase jugador reperesenta las caracteristicas y funcciones que representan a un jugador en u nuestro modelo de la FIFA
 * @author Lucas Martin Sebastian
 * @version 1.0
 * */
public class Jugador extends Persona {
	private int goles;
	private int asistencias;
	private int minutosJugados;
	private double efectividad;
	private int premiosGanados;
	/**
	 * Constructor vacio de la clase jugador , crea un objeto Jugador*/
	public Jugador()
	{
		
	}
	/**
	 * getGoles te permite recuperar el valor de la variable de instancia goles de la instancia de la clase Jugador
	 * @return devuelve la cantidad de goles que hizo el jugador*/
	public int getGoles() {
		return goles;
	}
	/**
	 * setGoles te permite asignarle un valor a la variable goles
	 * @param goles define el numero de goles del jugador*/
	public void setGoles(int goles) {
		this.goles = goles;
	}

	public int getAsistencias() {
		return asistencias;
	}

	public void setAsistencias(int asistencias) {
		this.asistencias = asistencias;
	}

	public int getMinutosJugados() {
		return minutosJugados;
	}

	public void setMinutosJugados(int minutosJugados) {
		this.minutosJugados = minutosJugados;
	}

	public double getEfectividad() {
		return efectividad;
	}

	public void setEfectividad(double efectividad) {
		this.efectividad = efectividad;
	}

	public int getPremiosGanados() {
		return premiosGanados;
	}

	public void setPremiosGanados(int premiosGanados) {
		this.premiosGanados = premiosGanados;
	}
}
