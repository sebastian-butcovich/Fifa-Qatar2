package paquetePrincipal;
/**
 * Clase persona que permite representar una persona dentro de nuestro modelo de FIFA
 * @author Martin Lucas Sebastian
 * @version 1.0
 **/
public  class  Persona {
	private String nombre;
	private String apellido;
	private int edad;
	private String rol;
	private String nacionalidad;
	private String genero;
	/**
	 * Construnctor de la clase Persona */
	public Persona()
	{
		
	}
	/**
	 * Permite obtener el nombre del jugador
	 * @return devuelve el nombre del objeto jugador*/
	public String getNombre() {
		return nombre;
	}
	/**
	 * Permite definir el nombre del jugador
	 * @param nombre tiene el nombre del Persona que se va a cargar en la instancia de la clase Persona*/
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}
	
}
