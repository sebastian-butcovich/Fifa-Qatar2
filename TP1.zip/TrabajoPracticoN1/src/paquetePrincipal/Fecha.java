package paquetePrincipal;
/**
 * Clase fecha representa una fecha en particular del calendario
 * @author  Lucas, Sebastian, Martin
 * @version 1.0 */
public class Fecha {
	private int year;
	private int mes;
	private int dia;
	private int hora;
	private int minutos;
	private int segundos;
	/**
	 * construnctor vacio de la clase fecha*/
	public Fecha()
	{
		
	}
	/**
	 * getYear es un metodo que devuelve la variables de instacia year
	 * @return devuelve el year de la fecha representada*/
	public int getYear() {
		return year;
	}
	/**
	 * setYear recibe un annio como parametro para asignarselo a la variable year
	 * @param  year da la fecha que se quiere representar*/
	public void setYear(int year) {
		this.year = year;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}

	public int getMinutos() {
		return minutos;
	}

	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}

	public int getSegundos() {
		return segundos;
	}

	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}
}
