package paquetePrincipal;
/**
 * Clase que representa un estadio
 * @author Lucas Sebastian Martin 
 * @version 1.0 */
public class Estadio {
	private String ciudad;
	private String estadio;
	private int capacidad;
	private boolean indoor;
	/**
	 * Constructor vacio de un estadio */
	public Estadio()
	{
		
	}

	public String getCiudad() {
		return ciudad;
	}
	/**
	 * setCiudad es un metodo que permite asignarle un valor a la variable de instancia ciudad
	 * @param ciudad es el nombre de la ciudad donde se encuentra el estadio*/
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	/**
	 * getEstadio te devuelve el valor de la variable estadio, la cual es un objeto de la clase Estadio
	 * @return devuelve el nombre del estadio*/
	public String getEstadio() {
		return estadio;
	}

	public void setEstadio(String estadio) {
		this.estadio = estadio;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public boolean isIndoor() {
		return indoor;
	}

	public void setIndoor(boolean indoor) {
		this.indoor = indoor;
	}
}
