package paquetePrincipal;
/**
 * Representacio de las caracteriticas y funcciones que tiene que cumplir un estadio en nuestro modelo del programa FIFA
 * @author Martin Sebastian Lucas
 * @version 1.0
 * */
public class Partido {
	private Lugar estadio;
	private Seleccion local;
	private Seleccion visitante;
	private int golesLocales;
	private int golesVisitante;
	private String instancia;
	/**
	 * Es el constructor de la clase partido*/
	public Partido()
	{
		
	}
	/** 
	 * Te permite conocer donde se va a jugar un partido, en que estadio
	 * @return devuelve el nombre del estadio*/
	public Lugar getEstadio() {
		return estadio;
	}
	/**
	 * Te permite definir donde se va a jugar un partido 
	 * @param estadio, una variable de clase estadio que se guarda dentro de partido
	 * @see Lugar*/
	public void setEstadio(Lugar estadio) {
		this.estadio = estadio;
	}
	/**
	 * getLocal devuelve el valor de la variable de instancia local
	 * @return devuelve un clase Seleccion*/
	public Seleccion getLocal() {
		return local;
	}
	/**
	 * setLocal le asigna un valor pasado por parametro a la variable de instancai local
	 * @param local tiene un valor de clase Seleccion*/
	public void setLocal(Seleccion local) {
		this.local = local;
	}
	/**
	 * getVisitantes devuelve el valor de la variable de instancia visitantes
	 * @return devuelve una clase Seleccion*/
	public Seleccion getVisitante() {
		return visitante;
	}
	/**
	 * setVisitante le asigna un valor a la variable de instancia visitante
	 * @param visitante tiene una clase Seleccion*/
	public void setVisitante(Seleccion visitante) {
		this.visitante = visitante;
	}
	/**
	 * getGolesLocales devuelve el valor de la variable de instancia golesLocales
	 * @return devuelve un valor numerico*/
	public int getGolesLocales() {
		return golesLocales;
	}
	/**
	 * setGolesLocales le asigna un valor pasado por parametro a la variable golesLocales
	 * @param golesLocales es un valor numerico*/
	public void setGolesLocales(int golesLocales) {
		this.golesLocales = golesLocales;
	}
	/**
	 * getGolesVisitantes devuelve el valor de la variable golesVisitante
	 * @return devuelve un valor numerico */
	public int getGolesVisitante() {
		return golesVisitante;
	}
	/**
	 *setGolesVisitantes le asigna un valor pasado por parametro a la variable de instancia golesVisitantes
	 *@param golesVisitante tiene un valor numerico*/
	public void setGolesVisitante(int golesVisitante) {
		this.golesVisitante = golesVisitante;
	}
	/**
	 * getInstancia devuelve el valor de la variable de instancias
	 * @return devuelve una cadena de caracteres*/
	public String getInstancia() {
		return instancia;
	}
	/**
	 * setInstancia le asigna un valor pasado por parametro  a la variable instancia\
	 * @param instancia es una cadena de caracteres*/
	public void setInstancia(String instancia) {
		this.instancia = instancia;
	}

}
