package paquetePrincipal;
/**
 * Representacio de las caracteriticas y funcciones que tiene que cumplir un estadio en nuestro modelo del programa FIFA
 * @author Martin Sebastian Lucas
 * @version 1.0
 * */
public class Partido {
	private Estadio estadio;
	private Seleccion local;
	private Seleccion visitante;
	private int golesLocales;
	private int golesVisitante;
	private String instancia;
	/**
	 * Es el constructor de la clase partido*/
	public Partido()
	{
		
	}
	/** 
	 * Te permite conocer donde se va a jugar un partido, en que estadio
	 * @return devuelve el nombre del estadio*/
	public Estadio getEstadio() {
		return estadio;
	}
	/**
	 * Te permite definir donde se va a jugar un partido 
	 * @param estadio, una variable de clase estadio que se guarda dentro de partido
	 * @see Estadio*/
	public void setEstadio(Estadio estadio) {
		this.estadio = estadio;
	}

	public Seleccion getLocal() {
		return local;
	}

	public void setLocal(Seleccion local) {
		this.local = local;
	}

	public Seleccion getVisitante() {
		return visitante;
	}

	public void setVisitante(Seleccion visitante) {
		this.visitante = visitante;
	}

	public int getGolesLocales() {
		return golesLocales;
	}

	public void setGolesLocales(int golesLocales) {
		this.golesLocales = golesLocales;
	}

	public int getGolesVisitante() {
		return golesVisitante;
	}

	public void setGolesVisitante(int golesVisitante) {
		this.golesVisitante = golesVisitante;
	}

	public String getInstancia() {
		return instancia;
	}

	public void setInstancia(String instancia) {
		this.instancia = instancia;
	}

}
