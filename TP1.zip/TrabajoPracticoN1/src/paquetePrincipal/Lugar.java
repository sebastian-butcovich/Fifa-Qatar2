package paquetePrincipal;
/**
 * Clase que representa un estadio
 * @author Lucas Sebastian Martin 
 * @version 1.0 */
public class Lugar {
	private String ciudad;
	private String estadio;
	private int capacidad;
	private boolean indoor;
	/**
	 * Constructor vacio de un estadio */
	public Lugar()
	{
		
	}
	/**
	 * getCiudad te devuelve el valor de la variable ciudad
	 * @return ciudad devuelve el nombre de la ciudad*/
	public String getCiudad() {
		return ciudad;
	}
	/**
	 * setCiudad es un metodo que permite asignarle un valor a la variable de instancia ciudad
	 * @param ciudad es el nombre de la ciudad donde se encuentra el estadio*/
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	/**
	 * getEstadio te devuelve el valor de la variable nombre, el cual es el valor del nombre del estadio
	 * @return devuelve el nombre del estadio*/
	public String getEstadio() {
		return estadio;
	}
	/**
	 *setEstadio le asigna un valor pasado por parametro a la variable nombre
	 *@param estadio tiene el valor que se le asigna a la variable nombre  */
	public void setEstadio(String estadio) {
		this.estadio = estadio;
	}
	/**
	 * getCapacidad devuelve el valor de la variable capacidad
	 * @return devuelve el valor de la variable capacidad*/
	public int getCapacidad() {
		return capacidad;
	}
	/**
	 * setCapacidad te permite asignarle un valor a la variable  capacidad
	 * @param capacidad tiene el valor que se le asigna a la variable capacidad*/
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	/**
	 * isIndoor te devuelve el valor de la variable indoor
	 * @return devuelve el valor de la variable indoor*/
	public boolean isIndoor() {
		return indoor;
	}
	/**
	 * setIndoor asigna un valor pasado por parametro a la variable indoor
	 * @param indoor tiene el valor que se le asigna a la variable indoor*/
	public void setIndoor(boolean indoor) {
		this.indoor = indoor;
	}
}
