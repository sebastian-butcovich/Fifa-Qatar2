package main;

public class Partido {
	private Estadio estadio;
	private Seleccion local;
	private Seleccion visitante;
	private Fecha fecha;
	private int golesLocales;
	private int golesVisitante;
	private String instancia;
	
	public Partido()
	{
		
	}

	public Estadio getEstadio() {
		return estadio;
	}

	public void setEstadio(Estadio estadio) {
		this.estadio = estadio;
	}

	public Seleccion getLocal() {
		return local;
	}

	public void setLocal(Seleccion local) {
		this.local = local;
	}

	public Seleccion getVisitante() {
		return visitante;
	}

	public void setVisitante(Seleccion visitante) {
		this.visitante = visitante;
	}

	public Fecha getFecha() {
		return fecha;
	}

	public void setFecha(Fecha fecha) {
		this.fecha = fecha;
	}

	public int getGolesLocales() {
		return golesLocales;
	}

	public void setGolesLocales(int golesLocales) {
		this.golesLocales = golesLocales;
	}

	public int getGolesVisitante() {
		return golesVisitante;
	}

	public void setGolesVisitante(int golesVisitante) {
		this.golesVisitante = golesVisitante;
	}

	public String getInstancia() {
		return instancia;
	}

	public void setInstancia(String instancia) {
		this.instancia = instancia;
	}

}
