package main;

public class Jugador extends Persona {
	private int goles;
	private int asistencias;
	private int minutosJugados;
	private double efectividad;
	private int premiosGanados;
	
	public Jugador()
	{
		
	}

	public int getGoles() {
		return goles;
	}

	public void setGoles(int goles) {
		this.goles = goles;
	}

	public int getAsistencias() {
		return asistencias;
	}

	public void setAsistencias(int asistencias) {
		this.asistencias = asistencias;
	}

	public int getMinutosJugados() {
		return minutosJugados;
	}

	public void setMinutosJugados(int minutosJugados) {
		this.minutosJugados = minutosJugados;
	}

	public double getEfectividad() {
		return efectividad;
	}

	public void setEfectividad(double efectividad) {
		this.efectividad = efectividad;
	}

	public int getPremiosGanados() {
		return premiosGanados;
	}

	public void setPremiosGanados(int premiosGanados) {
		this.premiosGanados = premiosGanados;
	}
}
