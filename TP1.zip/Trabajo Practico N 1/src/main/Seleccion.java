package main;

public class Seleccion {
	private Jugador[] seleccion;
	//private Estadisticas-Seleccion estadistica;
	private String confederacion;
	private int finales;
	
	public Seleccion()
	{
		
	}

	public Jugador[] getSeleccion() {
		return seleccion;
	}

	public void setSeleccion(Jugador[] seleccion) {
		this.seleccion = seleccion;
	}

	public String getConfederacion() {
		return confederacion;
	}

	public void setConfederacion(String confederacion) {
		this.confederacion = confederacion;
	}

	public int getFinales() {
		return finales;
	}

	public void setFinales(int finales) {
		this.finales = finales;
	}
	
}
