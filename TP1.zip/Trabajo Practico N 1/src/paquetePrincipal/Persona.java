package paquetePrincipal;
/**
 * Clase persona que permite representar una persona dentro de nuestro modelo de un Mundial
 * @author Martin Lucas Sebastian
 * @version 1.0
 **/
public  class  Persona {
	private String nombre;
	private String apellido;
	private int edad;
	private String rol;
	private String nacionalidad;
	private String genero;
	/**
	 * Construnctor de la clase Persona */
	public Persona()
	{
		
	}
	/**
	 * Permite obtener el nombre del jugador
	 * @return devuelve el nombre del objeto jugador*/
	public String getNombre() {
		return nombre;
	}
	/**
	 * Permite definir el nombre del jugador
	 * @param nombre tiene el nombre del Persona que se va a cargar en la instancia de la clase Persona*/
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * getApellido devuelve el valor de la variable de instancia apellido
	 * @return devuelve un valor numerico*/
	public String getApellido() {
		return apellido;
	}
	/**
	 * setApellido le asigna un valor pasado como parametro a la variable de instancia apellido
	 * @param apellido tiene un cadena de caracteres*/
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	/**
	 * getEdad devuelve el valor de la variable edad
	 * @return devuelve un valor numerico*/
	public int getEdad() {
		return edad;
	}
	/**
	 * setEdad le asigna un valor pasado como parametro a la variable de instancia edad
	 * @param edad es un valor numerico*/
	public void setEdad(int edad) {
		this.edad = edad;
	}
	/**
	 * getRol devuelve el valor de la variable rol
	 * @return devuelve una cadena de caracteres*/
	public String getRol() {
		return rol;
	}
	/**
	 * setRol le asigna un valor pasado como parametro a la variable de instancia rol
	 * @param rol es una cadena de caracteres*/
	public void setRol(String rol) {
		this.rol = rol;
	}
	/**
	 * getNacionalidad devuelve el valor de la variable de instancai nacionalidad
	 * @return devuelve una cadena de caracteres*/
	public String getNacionalidad() {
		return nacionalidad;
	}
	/**
	 * setNacionalidad le asigna un valor pasado como parametro a la variable de instancia nacionalidad 
	 * @param nacionalidad es una cadena de caracteres*/
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	/**
	 * getGenero devuelve el valor de la variable de instancia genero
	 * @return devuelve una cadena de caracteres*/
	public String getGenero() {
		return genero;
	}
	/**
	 * setGenero le asigna un valor a la variable de instancia genero
	 * @param genero es una cadena de caracteres*/
	public void setGenero(String genero) {
		this.genero = genero;
	}
	
}

