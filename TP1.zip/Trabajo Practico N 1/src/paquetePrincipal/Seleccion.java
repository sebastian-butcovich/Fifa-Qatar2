package paquetePrincipal;
/**
 * Define las caracteriticas y comportamientos que tiene una seleccion en nuestro modelo de un Mundial
 * @author Lucas, Martin, Sebastian
 * @version 1.0*/
public class Seleccion{
	private Jugador[] jugadores;
	//private Estadisticas-Seleccion estadistica;
	private Persona dt;
	
	/**
	 * constructor de la clase seleccion, no recibe parametro*/
	public Seleccion()
	{
		
	}
	/**
	 * Devuelve un arreglo de todos los jugadores de una seleccion en particular
	 * @return devuelve un arreglo de jugadores, con todos los jugadores de una seleccion
	 * @see Jugador*/
	public Jugador[] getJugadores() {
		return jugadores;
	}
	/**
	 * Define los jugadores de una seleccion
	 * @param seleccion es un arreglo que contiene jugadores de una seleccion
	 * @see Jugador*/
	public void setJugadores(Jugador[] jugadores) {
		this.jugadores = jugadores;
	}
	/**
	 * Devuelve el director tecnico de una seleccion
	 * @return devuelve una persona*/
	public Persona getDt() {
		return dt;
	}
	/**
	 * Define el dt de una seleccion
	 * @param dt es una persona*/
	public void setDt(Persona dt) {
		this.dt = dt;
	}
		
}

