package paquetePrincipal;
/**
 * Clase fecha representa una fecha en particular del calendario
 * @author  Lucas, Sebastian, Martin
 * @version 1.0 */
public class Fecha {
	private int year;
	private int mes;
	private int dia;
	private int hora;
	private int minutos;
	private int segundos;
	/**
	 * construnctor vacio de la clase fecha*/
	public Fecha()
	{
		
	}
	/**
	 * getYear es un metodo que devuelve la variables de instacia year
	 * @return devuelve el year de la fecha representada*/
	public int getYear() {
		return year;
	}
	/**
	 * setYear recibe un annio como parametro para asignarselo a la variable year
	 * @param  year da la fecha que se quiere representar*/
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * getMes devuelve el valor de la variable de instancia mes
	 * @return mes es devuelve el valor de un mes particular*/
	public int getMes() {
		return mes;
	}
	/**
	 * setMes asigna un valor pasado por parametro a la variable de instancia mes
	 * @param mes tiene el valor que se le asigna a la variable de instancia mes */
	public void setMes(int mes) {
		this.mes = mes;
	}
	/**
	 * getDia devuelve el valor de la variable dia
	 * @return dia devuelve un valor numerico*/
	public int getDia() {
		return dia;
	}
	/**
	 * setDia asigna un valor pasado por parametro a la variable dia
	 * @param dia tiene un valor numerico*/
	public void setDia(int dia) {
		this.dia = dia;
	}
	/**
	 * getHora devuelve el valor de la variable de instancia hora
	 * @return hora devuelve un valor numerico*/
	public int getHora() {
		return hora;
	}
	/**
	 * setHora asigna un valor pasado por parametro a la variable de instancia hora
	 * @param hora tiene un valor numerico*/
	public void setHora(int hora) {
		this.hora = hora;
	}
	/**
	 * getMinuto te devuelve el valor de la variable de instancia minutos
	 * @return te devuelve el valor de la variable de instancia minutos*/
	public int getMinutos() {
		return minutos;
	}
	/**
	 * setMinutos le asigna un valor pasador por parametro a la variable de instancia minutos
	 * @param minutos tiene un valor numerico*/
	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}
	/**
	 *getSegundos devuelve el valor de la variable de instancia segundos
	 *@return segundos devuelve un valor numerico */
	public int getSegundos() {
		return segundos;
	}
	/**
	 * setSegundos le asigna un valor a la variable de instancia segundos\
	 * @param segundos tiene un valor numerico
	 */
	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}
}
